<div class="menu menu-column menu-title-gray-800 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-500" id="#kt_aside_menu" data-kt-menu="true" data-kt-menu-expand="false">
    <div data-kt-menu-trigger="click" class="menu-item here show menu-accordion">
        <div class=" menu-active-bg">
            <div class="menu-item">
                <a class="menu-link <?php echo e(isActiveRoute('home')); ?>" href="<?php echo e(route('home')); ?>">
                    <span class="menu-bullet">
                        <span class="fa fa-home"></span>
                    </span>
                    <span class="menu-title">
                        الرئيسية
                    </span>
                </a>
            </div>
        </div>
    </div>
    <div class="menu-item">
        <div class="menu-content pt-8 pb-2">
            <span class="menu-section text-muted text-uppercase fs-8 ls-1">الصفحات</span>
        </div>
    </div>


<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.index')): ?>
    <!--begin::Menu item-->
<div class="menu-item menu-sub-indention menu-accordion  <?php echo e(areActiveRoutes(['roles.index' , 'roles.create' , 'roles.edit'])); ?>" data-kt-menu-trigger="click">
    <!--begin::Menu link-->
    <a href="#" class="menu-link py-3 <?php echo e(areActiveRoutes(['roles.index' , 'roles.create' , 'roles.edit'])); ?>">
        <span class="menu-icon">
            <img src="<?php echo e(asset('images/roles.png')); ?>" style="width:25px;height:25px">
        </span>
        <span class="menu-title"><?php echo app('translator')->get('dashboard.roles'); ?></span>
        <span class="menu-arrow"></span>
    </a>
    <!--end::Menu link-->

    <!--begin::Menu sub-->
    <div class="menu-sub menu-sub-accordion pt-3">
        <!--begin::Menu item-->
        <div class="menu-item">
            <a href="<?php echo e(route('roles.index')); ?>" class="menu-link py-3  <?php echo e(isActiveRoute('roles.index')); ?>">
                <span class="menu-bullet">
                    <span class="bullet bullet-dot"></span>
                </span>
                <span class="menu-title"><?php echo app('translator')->get('dashboard.all_title', ['page_title' => __('dashboard.roles')]); ?></span>
            </a>
        </div>
        <!--end::Menu item-->


        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.create')): ?>
        <!--begin::Menu item-->
        <div class="menu-item">
            <a href="<?php echo e(route('roles.create')); ?>" class="menu-link py-3 <?php echo e(isActiveRoute('roles.create')); ?>">
                <span class="menu-bullet">
                    <span class="bullet bullet-dot"></span>
                </span>
                <span class="menu-title"><?php echo app('translator')->get('dashboard.create_title', ['page_title' => __('dashboard.role')]); ?></span>
            </a>
        </div>
        <!--end::Menu item-->
        <?php endif; ?>
    </div>
    <!--end::Menu sub-->
</div>
<!--end::Menu item-->
<?php endif; ?> 
   
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admins.index')): ?>
    <!--begin::Menu item-->
    <div class="menu-item menu-sub-indention menu-accordion  <?php echo e(areActiveRoutes(['admins.index' , 'admins.create' , 'admins.edit'])); ?>" data-kt-menu-trigger="click">
        <!--begin::Menu link-->
        <a href="#" class="menu-link py-3 <?php echo e(areActiveRoutes(['admins.index' , 'admins.create' , 'admins.edit'])); ?>">
            <span class="menu-icon">
                    <img src="<?php echo e(asset('images/admins.png')); ?>" style="width:25px;height:25px">
            </span>
            <span class="menu-title"><?php echo app('translator')->get('dashboard.admins'); ?></span>
            <span class="menu-arrow"></span>
        </a>
        <!--end::Menu link-->

        <!--begin::Menu sub-->
        <div class="menu-sub menu-sub-accordion pt-3">
            <!--begin::Menu item-->
            <div class="menu-item">
                <a href="<?php echo e(route('admins.index')); ?>" class="menu-link py-3  <?php echo e(isActiveRoute('admins.index')); ?>">
                    <span class="menu-bullet">
                        <span class="bullet bullet-dot"></span>
                    </span>
                    <span class="menu-title"><?php echo app('translator')->get('dashboard.all_title', ['page_title' => __('dashboard.admins')]); ?></span>
                </a>
            </div>
            <!--end::Menu item-->

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admins.create')): ?>
            <!--begin::Menu item-->
            <div class="menu-item">
                <a href="<?php echo e(route('admins.create')); ?>" class="menu-link py-3 <?php echo e(isActiveRoute('admins.create')); ?>">
                    <span class="menu-bullet">
                        <span class="bullet bullet-dot"></span>
                    </span>
                    <span class="menu-title"><?php echo app('translator')->get('dashboard.create_title', ['page_title' => __('dashboard.admin')]); ?></span>
                </a>
            </div>
            <?php endif; ?> 
            <!--end::Menu item-->
        </div>
        <!--end::Menu sub-->
    </div>
    <!--end::Menu item-->
<?php endif; ?> 
   


    <!--begin::Menu item-->
    <div class="menu-item menu-sub-indention menu-accordion  <?php echo e(areActiveRoutes(['categories.index' , 'categories.create' , 'categories.edit'])); ?>" data-kt-menu-trigger="click">
        <!--begin::Menu link-->
        <a href="#" class="menu-link py-3 <?php echo e(areActiveRoutes(['categories.index' , 'categories.create' , 'categories.edit'])); ?>">
            <span class="menu-icon">
                <i class="bi bi-layers-fill fs-3"></i>
            </span>
            <span class="menu-title"><?php echo app('translator')->get('dashboard.categories'); ?></span>
            <span class="menu-arrow"></span>
        </a>
        <!--end::Menu link-->

        <!--begin::Menu sub-->
        <div class="menu-sub menu-sub-accordion pt-3">
            <!--begin::Menu item-->
            <div class="menu-item">
                <a href="<?php echo e(route('categories.index')); ?>" class="menu-link py-3  <?php echo e(isActiveRoute('categories.index')); ?>">
                    <span class="menu-bullet">
                        <span class="bullet bullet-dot"></span>
                    </span>
                    <span class="menu-title"><?php echo app('translator')->get('dashboard.all_title', ['page_title' => __('dashboard.categories')]); ?></span>
                </a>
            </div>
            <!--end::Menu item-->

            <!--begin::Menu item-->
            <div class="menu-item">
                <a href="<?php echo e(route('categories.create')); ?>" class="menu-link py-3 <?php echo e(isActiveRoute('categories.create')); ?>">
                    <span class="menu-bullet">
                        <span class="bullet bullet-dot"></span>
                    </span>
                    <span class="menu-title"><?php echo app('translator')->get('dashboard.create_title', ['page_title' => __('dashboard.category')]); ?></span>
                </a>
            </div>
            <!--end::Menu item-->
        </div>
        <!--end::Menu sub-->
    </div>
    <!--end::Menu item-->

    <!--begin::Menu item-->
    <div class="menu-item menu-sub-indention menu-accordion  <?php echo e(areActiveRoutes(['banners.index' , 'banners.create' , 'banners.edit'])); ?>" data-kt-menu-trigger="click">
        <!--begin::Menu link-->
        <a href="#" class="menu-link py-3 <?php echo e(areActiveRoutes(['banners.index' , 'banners.create' , 'banners.edit'])); ?>">
            <span class="menu-icon">
                <i class="bi bi-images fs-3"></i>
            </span>
            <span class="menu-title"><?php echo app('translator')->get('dashboard.banners'); ?></span>
            <span class="menu-arrow"></span>
        </a>
        <!--end::Menu link-->

        <!--begin::Menu sub-->
        <div class="menu-sub menu-sub-accordion pt-3">
            <!--begin::Menu item-->
            <div class="menu-item">
                <a href="<?php echo e(route('banners.index')); ?>" class="menu-link py-3  <?php echo e(isActiveRoute('banners.index')); ?>">
                    <span class="menu-bullet">
                        <span class="bullet bullet-dot"></span>
                    </span>
                    <span class="menu-title"><?php echo app('translator')->get('dashboard.all_title', ['page_title' => __('dashboard.banners')]); ?></span>
                </a>
            </div>
            <!--end::Menu item-->

            <!--begin::Menu item-->
            <div class="menu-item">
                <a href="<?php echo e(route('banners.create')); ?>" class="menu-link py-3 <?php echo e(isActiveRoute('banners.create')); ?>">
                    <span class="menu-bullet">
                        <span class="bullet bullet-dot"></span>
                    </span>
                    <span class="menu-title"><?php echo app('translator')->get('dashboard.create_title', ['page_title' => __('dashboard.banner')]); ?></span>
                </a>
            </div>
            <!--end::Menu item-->
        </div>
        <!--end::Menu sub-->
    </div>
    <!--end::Menu item-->
    <!--begin::Menu item-->
    <div class="menu-item menu-sub-indention menu-accordion  <?php echo e(areActiveRoutes(['initial-pages.index' , 'initial-pages.create' , 'initial-pages.edit'])); ?>" data-kt-menu-trigger="click">
        <!--begin::Menu link-->
        <a href="#" class="menu-link py-3 <?php echo e(areActiveRoutes(['initial-pages.index' , 'initial-pages.create' , 'initial-pages.edit'])); ?>">
            <span class="menu-icon">
                <i class="bi bi-book-half fs-3"></i>
            </span>
            <span class="menu-title"><?php echo app('translator')->get('dashboard.initial_pages'); ?></span>
            <span class="menu-arrow"></span>
        </a>
        <!--end::Menu link-->

        <!--begin::Menu sub-->
        <div class="menu-sub menu-sub-accordion pt-3">
            <!--begin::Menu item-->
            <div class="menu-item">
                <a href="<?php echo e(route('initial-pages.index')); ?>" class="menu-link py-3  <?php echo e(isActiveRoute('initial-pages.index')); ?>">
                    <span class="menu-bullet">
                        <span class="bullet bullet-dot"></span>
                    </span>
                    <span class="menu-title"><?php echo app('translator')->get('dashboard.all_title', ['page_title' => __('dashboard.initial_pages')]); ?></span>
                </a>
            </div>
            <!--end::Menu item-->

            <!--begin::Menu item-->
            <div class="menu-item">
                <a href="<?php echo e(route('initial-pages.create')); ?>" class="menu-link py-3 <?php echo e(isActiveRoute('initial-pages.create')); ?>">
                    <span class="menu-bullet">
                        <span class="bullet bullet-dot"></span>
                    </span>
                    <span class="menu-title"><?php echo app('translator')->get('dashboard.create_title', ['page_title' => __('dashboard.initial_page')]); ?></span>
                </a>
            </div>
            <!--end::Menu item-->
        </div>
        <!--end::Menu sub-->
    </div>
    <!--end::Menu item-->


<!--begin::Menu item-->
<div class="menu-item menu-sub-indention menu-accordion  <?php echo e(areActiveRoutes(['roles.index' , 'roles.create' , 'roles.edit'])); ?>" data-kt-menu-trigger="click">
    <!--begin::Menu link-->
    <a href="#" class="menu-link py-3 <?php echo e(areActiveRoutes(['roles.index' , 'roles.create' , 'roles.edit'])); ?>">
        <span class="menu-icon">
            <i class="bi bi-patch-check-fill fs-3"></i>
        </span>
        <span class="menu-title"><?php echo app('translator')->get('dashboard.roles'); ?></span>
        <span class="menu-arrow"></span>
    </a>
    <!--end::Menu link-->

    <!--begin::Menu sub-->
    <div class="menu-sub menu-sub-accordion pt-3">
        <!--begin::Menu item-->
        <div class="menu-item">
            <a href="<?php echo e(route('roles.index')); ?>" class="menu-link py-3  <?php echo e(isActiveRoute('roles.index')); ?>">
                <span class="menu-bullet">
                    <span class="bullet bullet-dot"></span>
                </span>
                <span class="menu-title"><?php echo app('translator')->get('dashboard.all_title', ['page_title' => __('dashboard.roles')]); ?></span>
            </a>
        </div>
        <!--end::Menu item-->

        <!--begin::Menu item-->
        <div class="menu-item">
            <a href="<?php echo e(route('roles.create')); ?>" class="menu-link py-3 <?php echo e(isActiveRoute('roles.create')); ?>">
                <span class="menu-bullet">
                    <span class="bullet bullet-dot"></span>
                </span>
                <span class="menu-title"><?php echo app('translator')->get('dashboard.create_title', ['page_title' => __('dashboard.role')]); ?></span>
            </a>
        </div>
        <!--end::Menu item-->
    </div>
    <!--end::Menu sub-->
</div>
<!--end::Menu item-->



    <!--begin::Menu item-->
    <div class="menu-item menu-sub-indention menu-accordion  <?php echo e(areActiveRoutes(['admins.index' , 'admins.create' , 'admins.edit'])); ?>" data-kt-menu-trigger="click">
        <!--begin::Menu link-->
        <a href="#" class="menu-link py-3 <?php echo e(areActiveRoutes(['admins.index' , 'admins.create' , 'admins.edit'])); ?>">
            <span class="menu-icon">
                <i class="bi bi bi-people fs-3"></i>
            </span>
            <span class="menu-title"><?php echo app('translator')->get('dashboard.admins'); ?></span>
            <span class="menu-arrow"></span>
        </a>
        <!--end::Menu link-->

        <!--begin::Menu sub-->
        <div class="menu-sub menu-sub-accordion pt-3">
            <!--begin::Menu item-->
            <div class="menu-item">
                <a href="<?php echo e(route('admins.index')); ?>" class="menu-link py-3  <?php echo e(isActiveRoute('admins.index')); ?>">
                    <span class="menu-bullet">
                        <span class="bullet bullet-dot"></span>
                    </span>
                    <span class="menu-title"><?php echo app('translator')->get('dashboard.all_title', ['page_title' => __('dashboard.admins')]); ?></span>
                </a>
            </div>
            <!--end::Menu item-->

            <!--begin::Menu item-->
            <div class="menu-item">
                <a href="<?php echo e(route('admins.create')); ?>" class="menu-link py-3 <?php echo e(isActiveRoute('admins.create')); ?>">
                    <span class="menu-bullet">
                        <span class="bullet bullet-dot"></span>
                    </span>
                    <span class="menu-title"><?php echo app('translator')->get('dashboard.create_title', ['page_title' => __('dashboard.admin')]); ?></span>
                </a>
            </div>
            <!--end::Menu item-->
        </div>
        <!--end::Menu sub-->
    </div>
    <!--end::Menu item-->



     <!--begin::Menu item-->
     <div class="menu-item menu-sub-indention menu-accordion  <?php echo e(areActiveRoutes(['orders.index' , 'orders.orders-by-status'])); ?>" data-kt-menu-trigger="click">
        <!--begin::Menu link-->
        <a href="#" class="menu-link py-3 <?php echo e(areActiveRoutes(['orders.index' , 'orders.orders-by-status'])); ?>">
            <span class="menu-icon">
                <i class="bi bi bi-cart4 fs-3"></i>
            </span>
            <span class="menu-title"><?php echo app('translator')->get('dashboard.orders'); ?></span>
            <span class="menu-arrow"></span>
        </a>
        <!--end::Menu link-->

        <!--begin::Menu sub-->
        <div class="menu-sub menu-sub-accordion pt-3">
            <!--begin::Menu item-->
           
                <div class="menu-item">
                    <a href="<?php echo e(route('orders.index')); ?>" class="menu-link py-3 <?php echo e(isActiveRoute('orders.index')); ?>">
                        <span class="menu-bullet">
                            <span class="bullet bullet-dot"></span>
                        </span>
                        <span class="menu-title"><?php echo app('translator')->get('dashboard.all_title', ['page_title' => __('dashboard.orders')]); ?></span>
                    </a>
                </div>
                <div class="menu-item">
                    <a class="menu-link <?php echo e(isActiveURLSegment('pending' , 2)); ?>" href="<?php echo e(route('orders.orders-by-status' , ['status' => 'pending'])); ?>">
                        <span class="menu-bullet">
                            <span class="bullet bullet-dot"></span>
                        </span>
                        <span class="menu-title"><?php echo app('translator')->get('apis.pending_orders'); ?></span>
                    </a>
                </div>
                <div class="menu-item">
                    <a href="<?php echo e(route('orders.orders-by-status' , ['status' => 'preparing'])); ?>" class="menu-link py-3 <?php echo e(isActiveURLSegment('preparing' , 2)); ?>">
                        <span class="menu-bullet">
                            <span class="bullet bullet-dot"></span>
                        </span>
                        <span class="menu-title"><?php echo app('translator')->get('apis.preparing_orders'); ?></span>
                    </a>
                </div>
                <div class="menu-item">
                    <a href="<?php echo e(route('orders.orders-by-status' , ['status' => 'done'])); ?>" class="menu-link py-3 <?php echo e(isActiveURLSegment('done' , 2)); ?>">
                        <span class="menu-bullet">
                            <span class="bullet bullet-dot"></span>
                        </span>
                        <span class="menu-title"><?php echo app('translator')->get('apis.done_orders'); ?></span>
                    </a>
                </div>
                <div class="menu-item">
                    <a href="<?php echo e(route('orders.orders-by-status' , ['status' => 'cancelled'])); ?>" class="menu-link py-3 <?php echo e(isActiveURLSegment('cancelled' , 2)); ?>">
                        <span class="menu-bullet">
                            <span class="bullet bullet-dot"></span>
                        </span>
                        <span class="menu-title"><?php echo app('translator')->get('apis.cancelled_orders'); ?></span>
                    </a>
                </div>
                
                
               
        </div>
        <!--end::Menu sub-->
    </div>
    <!--end::Menu item-->


    <!--begin::Menu item-->
    <div class="menu-item menu-sub-indention menu-accordion  <?php echo e(areActiveRoutes(['users.index' , 'users.create' , 'users.edit'])); ?>" data-kt-menu-trigger="click">
        <!--begin::Menu link-->
        <a href="#" class="menu-link py-3 <?php echo e(areActiveRoutes(['users.index' , 'users.create' , 'users.edit'])); ?>">
            <span class="menu-icon">
                <i class="bi bi-people-fill fs-3"></i>
            </span>
            <span class="menu-title"><?php echo app('translator')->get('dashboard.users'); ?></span>
            <span class="menu-arrow"></span>
        </a>
        <!--end::Menu link-->

        <!--begin::Menu sub-->
        <div class="menu-sub menu-sub-accordion pt-3">
            <!--begin::Menu item-->
            <div class="menu-item">
                <a href="<?php echo e(route('users.index')); ?>" class="menu-link py-3  <?php echo e(isActiveRoute('users.index')); ?>">
                    <span class="menu-bullet">
                        <span class="bullet bullet-dot"></span>
                    </span>
                    <span class="menu-title"><?php echo app('translator')->get('dashboard.all_title', ['page_title' => __('dashboard.users')]); ?></span>
                </a>
            </div>
            <!--end::Menu item-->

            <!--begin::Menu item-->
            <div class="menu-item">
                <a href="<?php echo e(route('users.create')); ?>" class="menu-link py-3 <?php echo e(isActiveRoute('users.create')); ?>">
                    <span class="menu-bullet">
                        <span class="bullet bullet-dot"></span>
                    </span>
                    <span class="menu-title"><?php echo app('translator')->get('dashboard.create_title', ['page_title' => __('dashboard.user')]); ?></span>
                </a>
            </div>
            <!--end::Menu item-->
        </div>
        <!--end::Menu sub-->
    </div>
    <!--end::Menu item-->

    

    <!--begin::Menu item-->
    <div class="menu-item menu-sub-indention menu-accordion  <?php echo e(areActiveRoutes(['notifications.index' , 'notifications.create'])); ?>" data-kt-menu-trigger="click">
        <!--begin::Menu link-->
        <a href="#" class="menu-link py-3 <?php echo e(areActiveRoutes(['notifications.index' , 'notifications.create'])); ?>">
            <span class="menu-icon">
                <i class="bi bi-bell fs-3"></i>
            </span>
            <span class="menu-title"><?php echo app('translator')->get('dashboard.notifications'); ?></span>
            <span class="menu-arrow"></span>
        </a>
        <!--end::Menu link-->

        <!--begin::Menu sub-->
        <div class="menu-sub menu-sub-accordion pt-3">
            <!--begin::Menu item-->
            <div class="menu-item">
                <a href="<?php echo e(route('notifications.index')); ?>" class="menu-link py-3  <?php echo e(isActiveRoute('notifications.index')); ?>">
                    <span class="menu-bullet">
                        <span class="bullet bullet-dot"></span>
                    </span>
                    <span class="menu-title"><?php echo app('translator')->get('dashboard.all_title', ['page_title' => __('dashboard.notifications')]); ?></span>
                </a>
            </div>
            <!--end::Menu item-->

            <!--begin::Menu item-->
            <div class="menu-item">
                <a href="<?php echo e(route('notifications.create')); ?>" class="menu-link py-3 <?php echo e(isActiveRoute('notifications.create')); ?>">
                    <span class="menu-bullet">
                        <span class="bullet bullet-dot"></span>
                    </span>
                    <span class="menu-title"><?php echo app('translator')->get('dashboard.send_notification'); ?></span>
                </a>
            </div>
            <!--end::Menu item-->
        </div>
        <!--end::Menu sub-->
    </div>
    <!--end::Menu item-->
    
    <!--Start :Single Menu item-->
        <!--begin::Menu item-->
        <div class="menu-item">
            <a href="<?php echo e(route('settings')); ?>" class="menu-link py-3">
                <span class="menu-icon">
                    <i class="bi bi-gear fs-3"></i>
                </span>
                <span class="menu-title"><?php echo app('translator')->get('dashboard.settings'); ?></span>
            </a>
        </div>
        <!--end::Menu item-->
    <!--End:Single Menu item-->
</div><?php /**PATH C:\laragon\www\base\resources\views/dashboard/layouts/menu.blade.php ENDPATH**/ ?>